# WBS v2 — 운영 이식용 디자인 템플릿 가이드

> 이 문서는 정적 디자인 시안(`index_v2.html` / `styles_v2.css`)을 **운영 WBS에 단계적으로 안전하게 이식**하기 위한 설계 문서입니다.
> 운영 코드를 직접 수정하지 않으며, Firebase/Firestore/저장/필터/편집 로직은 전부 운영 JS가 그대로 담당합니다.
> 이 템플릿이 책임지는 것은 **마크업 구조 · class 체계 · CSS 토큰**뿐입니다.

---

## 0. 파일 구성

| 파일 | 역할 | 이식 대상 |
|---|---|---|
| `index.html` | **SaaS 대시보드형 정석 템플릿.** 13개 섹션(`SECTION 1..13` 주석)으로 이식 단위 구분, 18열 테이블, 운영 ID 전부 포함 | 마크업 구조 참고 (그대로 복사 X, 구조·class·ID 이식) |
| `index_v2.html` | 13열 경량 프리뷰(초안). 동일 class 체계의 축약본 | 보조 참고 |
| `index_legacy.html` | 이전 app.js 기반 인터랙티브 프로토타입 백업 | 기능 동작 참고용 (이식 대상 아님) |
| `styles_v2.css` | `.wbs-` prefix 컴포넌트 CSS + 폰트 override. **운영 이식용 스타일시트** | **운영 CSS에 단계적으로 병합** (통합 시 `styles.css`로 rename 가능) |
| `styles.css` | `index_legacy.html` 전용 구(舊) 스타일 | 이식 대상 아님 |
| `colors_and_type.css` | Wanted DS 토큰 (색/간격/radius/타입 램프) | 토큰만 참조. 폰트는 `styles_v2.css`에서 override |
| `design-implementation-guide.md` | 본 문서 | — |

### 폰트 정책 (중요)
- **HGGGOTHICSSI 사용 안 함.** `fonts/` 의 OTF는 로드하지 않습니다.
- `styles_v2.css` 최상단에서 `--font-sans` / `--font-display` 를 **S-CoreDream(에스코어드림) → Noto Sans KR → system-ui** 로 override 합니다.
- S-CoreDream은 CDN(`jsdelivr`)에서 woff(Light~Heavy)로 불러옵니다. 오프라인/사내망이면 운영에 있는 S-CoreDream 경로로 `@font-face` src만 교체하세요.
- DS 타입 램프(`--font-title-3` 등)가 전부 `var(--font-sans)` 를 참조하므로, **토큰 하나만 바꾸면 전체 폰트가 교체**됩니다. 개별 셀렉터를 건드릴 필요 없음.

---

## 1. WBS v2 레이아웃 구조 (13개 이식 단위)

`index.html` 의 `SECTION 1..13` 주석이 각 단위를 표시합니다.

```
1  App shell               .wbs-shell                 기본 자연 스크롤, 옵션 --app 고정뷰
2  Topbar / project header .wbs-topbar
   ├ 프로젝트명             #projectName .wbs-project__input
   ├ 동기화 상태            #syncStatus  .wbs-savechip
   ├ 다크/큰글씨            #btnThemeToggle / #btnSeniorFont
   └ 계정/인증 바           #wbsAuthBar  .wbs-authbar
3  Summary / KPI cards     #summaryCards .wbs-summary-grid > .wbs-kpi-card
4  Completion ring         .wbs-completion-ring > #progressFill / #progressLabel
   ├ 기준일/착수일          #baseDate / #startDate .wbs-datefield
   └ 문서 용량              #payloadSizeWrap .wbs-payload
5  Toolbar                 .wbs-toolbar
   └ #btnAdd #btnAddGroup #btnDelete #btnUndo #btnImportExcel #btnExportExcel
     #btnExcelSample #btnHardRefresh #btnBackfillEffort #btnRegister
     #importExcelFile(hidden) #wbsRowCountLabel
6  Table card              .wbs-table-wrap > .wbs-table-card > table#wbsTable
7  Table header            thead#tableHead   (18열)
8  Table body row          tbody#tableBody > tr.wbs-row
9  Group row               tr.wbs-group-row > td[colspan=18] > .wbs-group-row__cell
10 Status badge            .wbs-status-pill--{done|prog|wait}
11 Judgment badge          .wbs-judgment-pill--{normal|notstarted|ongoing|over|early}
12 Quick navigation / rail #wbsGroupNav .wbs-quick-nav  +  #btnScrollTop
13 Bottom tabs / sheet bar .wbs-sheet-bar (운영 sheet-bar.js 출력 매칭용)
```

★ 모든 `#id` 는 운영 WBS가 바인딩하는 ID. 이름을 **그대로 유지**했으므로 운영 JS 셀렉터 변경 불필요.

---

## 2. 운영 ID / class 매핑표

| 운영 ID (유지) | 섹션 | v2 class |
|---|---|---|
| `#projectName` | 2 | `.wbs-project__input` |
| `#syncStatus` | 2 | `.wbs-savechip` |
| `#wbsAuthBar` | 2 | `.wbs-authbar` |
| `#btnThemeToggle` `#btnSeniorFont` | 2 | `.wbs-iconbtn` |
| `#summaryCards` | 3 | `.wbs-summary-grid` (자식 `.wbs-kpi-card`) |
| `#progressFill` `#progressLabel` | 4 | `.wbs-completion-ring` 내부 / `__pct` |
| `#baseDate` `#startDate` | 4 | `.wbs-datefield__input` |
| `#payloadSizeWrap` | 4 | `.wbs-payload` |
| `#btnAdd` `#btnAddGroup` `#btnDelete` `#btnUndo` | 5 | `.wbs-btn` (+변형) |
| `#btnImportExcel` `#btnExportExcel` `#btnExcelSample` `#btnRegister` | 5 | `.wbs-btn` (+변형) |
| `#btnHardRefresh` `#btnBackfillEffort` | 5 | `.wbs-iconbtn` |
| `#importExcelFile` | 5 | hidden `<input type=file>` (`.wbs-hidden`) |
| `#wbsRowCountLabel` | 5 | `.wbs-countchip b` |
| `#wbsTable` | 6 | `.wbs-table` |
| `#tableHead` | 7 | `thead` (`.wbs-table thead th`) |
| `#tableBody` | 8 | `tbody` (`.wbs-table tbody td`), 행=`tr.wbs-row` |
| (그룹 행) | 9 | `tr.wbs-group-row` + `td[colspan]` ← **운영 실제 컬럼 수로** |
| (상태 셀) | 10 | `.wbs-status-pill--{done\|prog\|wait}` |
| (판정 셀) | 11 | `.wbs-judgment-pill--{normal\|notstarted\|ongoing\|over\|early}` |
| `#wbsGroupNav` `#btnScrollTop` | 12 | `.wbs-quick-nav` / `__top` |
| (sheet-bar) | 13 | `.wbs-sheet-bar` / `__tab` |

**충돌 방지:** 모든 신규 class 는 `wbs-` prefix + BEM(`block__element--modifier`). 운영의 일반명 class(`.btn`/`.card`/`.row`)와 겹치지 않음.

---

## 3. CSS만으로 가능한 영역 (HTML 변경 불필요 / 저위험)

운영 마크업을 거의 안 건드리고 **CSS 병합만으로** 효과를 보는 부분:

- 상태/판정 **배지 색감·radius·패딩** — 운영 셀 안의 텍스트를 `<span class="wbs-status-pill ...">` 로 감싸기만 하면 됨
- **버튼 높이·radius·hover** — 기존 버튼에 `.wbs-btn` 추가
- **테이블 헤더 대비·행 높이** — `.wbs-table` class만 부여하면 `thead th` / `tbody td` 규칙 적용
- **카드 외곽선·그림자·배경색** — `.wbs-table-card`, `.wbs-kpi-card`
- **폰트 전체 교체** — `--font-sans` override 한 곳 (셀렉터 변경 0)
- **배경/라인 색** — DS 토큰이 이미 처리

> 행 높이·폰트 스케일은 `:root` 의 `--wbs-row-py`, `--wbs-fs`, `--wbs-control-h` 노브로 환경별 미세조정 가능.

---

## 4. HTML 수정이 필요한 영역 (중위험)

마크업 구조를 맞춰야 스타일이 붙는 부분 — 운영 템플릿/렌더 함수 수정 필요:

- **완료율 ring** — 운영이 막대바면 `.wbs-progress` 구조를, ring이면 SVG 2-circle 구조를 추가해야 함. (둘 다 제공 — 운영 방식 택1)
- **KPI 카드 내부 구조** — `.wbs-kpi-card__top`(dot+name) / `.wbs-kpi-card__val` 2-레벨. 운영 `#summaryCards` 렌더 함수의 출력 마크업을 이 구조로.
- **그룹 행 내부** — `.wbs-group-row__cell` 안에 chevron/name/count/progress 배치. 운영 그룹 행 렌더 수정.
- **셀 내부 래핑** — 담당자(`.wbs-person`+아바타), LV칩(`.wbs-lvchip`), 우선순위(`.wbs-prio`) 등은 텍스트를 span으로 감싸는 작업.

---

## 5. JS 수정이 필요한 영역 (운영 JS — 신규 작성 아님, 출력 마크업 조정만)

> **신규 app.js/data.js 생성 금지.** 아래는 운영 JS의 *기존* 렌더 함수가 뱉는 마크업에 class/구조를 맞추는 수준의 조정입니다.

- `#summaryCards` 렌더: 카드 1장을 `.wbs-kpi-card` 구조로 출력
- `#tableBody` 행 렌더: 상태값 → `.wbs-status-pill--*`, 판정값 → `.wbs-judgment-pill--*` modifier 부여
- 그룹 행 렌더: `colspan` 을 실제 컬럼 수로, 내부를 `.wbs-group-row__cell` 로
- `#progressFill` 업데이트: ring이면 `stroke-dashoffset = 226.19 * (1 - pct/100)`, bar면 `width = pct%`
- `#wbsGroupNav` 항목: `.wbs-quick-nav__item` + `data-jump` (스크롤 로직은 운영 그대로)
- 큰글씨 모드: `<html data-fontmode="large">` 토글 (CSS가 `--wbs-fs` 처리)

이식 시 **로직은 건드리지 않고**, 템플릿 문자열(class 이름)만 교체하는 것이 핵심입니다.

---

## 6. 위험 요소 & 운영 구조 존중 사항

| 위험 패턴 | v2 템플릿의 처리 | 운영 이식 시 |
|---|---|---|
| `height: 100vh` | 기본 미적용. `.wbs-shell--app` **opt-in** 으로만 | 운영이 body 스크롤이면 `--app` 빼고 그대로 |
| `overflow: hidden` | `--app` 모드에서만 | 동일 |
| 내부 table scroll 전환 | `--app` 모드 + `.wbs-table-wrap{overflow:auto}` 에서만 | 운영 sticky-scroll 구조를 **그대로 두고** class만 부여 |
| 그룹행 `colspan=18` 고정 | colspan을 **13으로 예시**, CSS는 값 비의존 | 운영 실제 컬럼 수로 설정 |
| toolbar ID 제거 | ID **전부 보존** | 그대로 |
| 18열 고정 가정 | 컬럼 수 가정 안 함 (`auto-fit` KPI, colspan 가변) | 컬럼 추가/삭제 자유 |
| sheet-bar를 정적 tabs로 대체 | 정적 `.wbs-sheet-bar` 는 **시각 참고용**만 | 운영 `sheet-bar.js` 출력에 class만 매핑, 대체하지 않음 |

> 한 줄 요약: **구조를 바꾸라고 강요하지 않고, 운영 구조 위에 class와 토큰을 얹는** 방식.

---

## 7. 단계별 운영 이식 가이드 (우선순위 순)

> 우선순위 = 위험도 낮고 효과 큰 순. 각 단계는 **독립 머지/롤백** 가능하도록 설계됨.
> 형식: ① 참고 class · ② 운영 즉시 적용 가능 여부 · ③ 위험 구조 여부 · ④ Cursor 주의점

---

### 우선순위 1 — Badge / Pill (상태 · 기간판정)
- **① 참고 class**
  `styles_v2.css §7` — `.wbs-status-pill` + `--done/--prog/--wait`, `.wbs-judgment-pill` + `--normal/--notstarted/--ongoing/--over/--early`.
  부가: `.wbs-prio`(우선순위 dot), `.wbs-lvchip`(LV 칩).
- **② 운영 즉시 적용** ✅ **가능.** 셀 텍스트를 `<span class="wbs-status-pill wbs-status-pill--done">`로 감싸기만 하면 됨. 레이아웃/스크롤 영향 0.
- **③ 위험 구조** 🟢 **없음.** 순수 표현 요소. DOM 구조·컬럼 수와 무관.
- **④ Cursor 주의점**
  - 운영 **상태/판정 문자열 값 → modifier** 매핑표를 먼저 고정 (예: `"완료"→--done`, `"기간초과"→--over`).
  - 색은 DS 토큰만(`var(--color-positive)` 등). 임의 hex 금지.
  - 판정 pill은 `min-width`로 폭 통일돼 있음 — 열 정렬 깨지면 이 값만 조정.

---

### 우선순위 2 — Toolbar
- **① 참고 class**
  `§3` `.wbs-btn` + `--primary/--positive/--ghost/--danger`, `§5` `.wbs-toolbar`/`__group`/`__spacer`, `.wbs-search`, `.wbs-countchip`, `.wbs-iconbtn`.
- **② 운영 즉시 적용** ✅ **가능.** 기존 버튼에 class만 추가. 높이는 `--wbs-control-h`(기본 38px) 토큰 1개로 일괄 조정.
- **③ 위험 구조** 🟢 **거의 없음.** 단, toolbar가 `display:flex`라 운영이 `float`/`inline` 기반이면 컨테이너만 flex로.
- **④ Cursor 주의점**
  - **버튼 ID 절대 변경 금지** (`#addRowBtn`/`#groupBtn`/`#delBtn`/`#importBtn`/`#exportBtn`/`#saveBtn`). class만 추가.
  - 아이콘은 mask 방식(`.wbs-ic` + `--m:url(...)`) — `currentColor`를 따르므로 다크모드·컬러버튼에서 자동 대응. `<img>`로 바꾸지 말 것.

---

### 우선순위 3 — Table-card
- **① 참고 class**
  `§6` `.wbs-table-wrap`(영역), `.wbs-table-card`(외곽), `.wbs-table`(`thead th`/`tbody td` 규칙), `.wbs-group-row`+`__cell/__name/__track/__pct`, 셀 헬퍼(`.wbs-id`/`.wbs-date`/`.wbs-num`/`.wbs-person`/`.wbs-reqlink`).
- **② 운영 즉시 적용** 🟡 **부분.** 카드 외곽선·헤더 대비·행 높이는 class 추가로 즉시. **그룹 행 내부 구조**는 마크업 조정 필요.
- **③ 위험 구조** 🔴 **주의.** 아래는 운영 구조를 존중해 **건드리지 말 것**:
  - sticky header / 내부 table scroll → v2는 `.wbs-shell--app` **opt-in**일 때만 적용. 운영이 body 스크롤이면 그대로 둠.
  - 그룹 행 `colspan` → **운영 실제 컬럼 수**로 설정 (CSS는 값에 비의존, 18 고정 가정 없음).
- **④ Cursor 주의점**
  - 행 높이는 `--wbs-row-py`(기본 9px) 토큰으로 조정 — 셀 패딩 직접 수정 X.
  - `#wbsTable`/`#tableHead`/`#tableBody` ID 유지. `.wbs-table` class만 부여.
  - 긴 작업명 말줄임·`white-space:nowrap` 확인(컬럼 폭 운영값 우선).

---

### 우선순위 4 — KPI / Completion ring
- **① 참고 class**
  `§4` `.wbs-summary`(영역), `#summaryCards`=`.wbs-summary-grid`, `.wbs-kpi-card`+`__top/__dot/__name/__val`, `.wbs-completion`+`.wbs-completion-ring`+`__pct`, 막대 대안 `.wbs-progress`/`__fill`, 날짜 `.wbs-datefield`.
- **② 운영 즉시 적용** 🟡 **부분.** KPI 카드는 `#summaryCards` 렌더 함수의 출력 마크업을 `.wbs-kpi-card` 구조로. ring은 SVG 구조 추가 필요.
- **③ 위험 구조** 🟢 **낮음.** 고정 위치/스크롤 잠금 없음. 카드 개수는 `auto-fit` 그리드라 가변 안전.
- **④ Cursor 주의점**
  - `#progressFill`/`#progressLabel` ID 유지. **ring**이면 `stroke-dashoffset = 226.19 × (1 − pct/100)`, **막대바**면 `.wbs-progress__fill{width:pct%}` — 운영 방식 택1(둘 다 제공).
  - 숫자는 `tabular-nums` 적용돼 자릿수 정렬됨 — 폰트 교체 후에도 유지.
  - `#baseDate`/`#startDate` input ID 유지.

---

### 우선순위 5 — Quick nav / Rail
- **① 참고 class**
  `§8` `#wbsGroupNav`=`.wbs-quick-nav`, `__item`/`__dot`/`__divider`/`__top`.
- **② 운영 즉시 적용** ✅ **가능.** class 추가 + 그룹 이동 로직은 운영 그대로.
- **③ 위험 구조** 🟡 **`position:fixed`.** 화면에 떠다니는 요소라 다른 fixed 요소와 **z-index 충돌** 가능.
- **④ Cursor 주의점**
  - rail의 `z-index:30` 과 운영 헤더/모달 레이어 우선순위 확인.
  - 항목은 `data-jump="그룹id"` — 스크롤 타깃은 운영 그룹 행의 식별자에 매핑.
  - 모바일/좁은 화면에서 가릴 수 있으니 필요 시 `@media`로 숨김 처리.

---

### (참고) 우선순위 외 — 폰트
- `styles_v2.css §0` 의 `--font-sans` override (S-CoreDream / 에스코어드림).
- CDN 차단 시 사내 경로로 `@font-face src`만 교체. **HGGGOTHICSSI 도입 안 함.**
- 토큰 1곳만 바꾸면 전체 타입 램프가 교체됨. 적용 후 한글 폭/줄바꿈 1회 점검.

---

## 8. Cursor 인계 핵심 포인트

1. **ID는 전부 그대로.** 운영이 바인딩하는 `#projectName`, `#summaryCards`, `#progressFill`, `#wbsTable`, `#tableBody`, `#wbsGroupNav`, toolbar 버튼 ID를 보존했다. 셀렉터 리네이밍 PR 만들지 말 것.
2. **신규 JS 파일 만들지 말 것.** `index_v2.html` 의 `<script>` 는 *프리뷰 전용*(테마/큰글씨/스크롤)이며 이식 대상이 아니다. 통합 시 삭제.
3. **CSS는 단계별 병합.** §1→§9 순서가 곧 이식 순서. 한 번에 통째로 머지하지 말고 1~7단계로 쪼갤 것.
4. **구조 강제 금지.** `100vh`/`overflow:hidden`/`table scroll`/`colspan=18` 은 전부 opt-in 또는 가변. 운영 레이아웃을 존중한다.
5. **토큰만 사용.** 색/간격/radius/타입은 `colors_and_type.css` 의 `var(--*)` 만. 임의 hex 금지.
6. **폰트는 토큰 1곳.** `--font-sans` override 외에는 폰트 관련 코드를 만지지 않는다.
7. **검증 체크리스트:** 라이트/다크 토글, 큰글씨(`data-fontmode="large"`), 컬럼 수 변경, 그룹 접기, 긴 작업명 말줄임 — 5개만 통과하면 안전.
