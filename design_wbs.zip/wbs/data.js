/* WBS dataset — recreated from the live 파르나스 운영(네오) board */

const PEOPLE = {
  "심성봉": "#0066FF", "윤혜현": "#6541F2", "더파르나스": "#00BDDE",
  "월말 정기 작업": "#878A93", "이광석": "#FF5E00", "임보라": "#F553DA",
  "최정현": "#00BF40", "진영우": "#0054D1", "최영우": "#CC4B00", "이서연": "#3A16C9",
};

// status: done | prog | wait    judgment: normal | notstarted | ongoing | over | early
const GROUPS = [
  {
    id: "rewards", name: "리워즈", color: "#0066FF",
    tasks: [
      { sr:1, id:"RWD_149", lv1:"FO", lv2:"운영", title:"메인페이지 빅배너(KV) 교체", isNew:true, req:"RWD_012", reqby:"심성봉", worker:"", date:"2026-05-29", prio:3, status:"wait", est:null, start:null, end:null, act:null, judge:"notstarted", note:"" },
      { sr:1, id:"RWD_148", lv1:"FO", lv2:"콘텐츠 추가", title:"기업소개 내 소요한남 콘텐츠 추가", isNew:true, req:"RWD_011", reqby:"심성봉", worker:"", date:"2026-05-29", prio:3, status:"wait", est:null, start:null, end:null, act:null, judge:"notstarted", note:"" },
      { sr:1, id:"RWD_147", lv1:"FO", lv2:"운영업무", title:"모바일채널에서 대표이사 메세지 숨김 처리 (추가)", isNew:true, req:"RWD_010", reqby:"심성봉", worker:"", date:"2026-05-29", prio:3, status:"wait", est:null, start:null, end:null, act:null, judge:"notstarted", note:"" },
      { sr:1, id:"RWD_146", lv1:"FO", lv2:"운영업무", title:"모바일채널에서 대표이사 메세지 숨김 처리", req:"RWD_009", reqby:"심성봉", worker:"진영우", date:"2026-05-28", prio:3, status:"done", est:1, start:"2026-05-29", end:"2026-05-29", act:1, judge:"normal", note:"" },
      { sr:1, id:"RWD_145", lv1:"운영", lv2:"바우처 재반영", title:"사용된 바우처의 빌 정보 변경 요청. 사용 처리중 결제 방식이 잘못…", reqby:"윤혜현", worker:"진영우", date:"2026-05-28", prio:3, status:"done", est:1, start:"2026-05-28", end:"2026-05-28", act:1, judge:"normal", note:"[메일] 바우처 재처리 요청 05월 28일 리워즈 식음 전용 5만…" },
      { sr:1, id:"RWD_144", lv1:"운영", lv2:"로그 확인", title:"예약번호 : 380045 로그 확인 요청", reqby:"심성봉", worker:"진영우", date:"2026-05-28", prio:3, status:"done", est:1, start:"2026-05-28", end:"2026-05-28", act:1, judge:"normal", note:"[메시지] 예약 취소가 되었는데, 사유 확인하기 위함 (예약…" },
      { sr:1, id:"RWD_143", lv1:"운영", lv2:"기업회원 인증", title:"현대자동차 기업회원 인증 데이터 추출", reqby:"심성봉", worker:"진영우", date:"2026-05-28", prio:3, status:"done", est:1, start:"2026-05-28", end:"2026-05-28", act:1, judge:"normal", note:"[메시지] 현대자동차 인증 관련, 데이터 추출 요청 건" },
      { sr:1, id:"RWD_142", lv1:"운영", lv2:"5월 포인트 정산", title:"5월 포인트 정산 작업.", reqby:"월말 정기 작업", worker:"진영우", date:"2026-05-28", prio:3, status:"prog", est:2, start:"2026-05-28", end:null, act:null, judge:"ongoing", note:"5월 포인트 적립, 차감, 소멸 정산 작업." },
      { sr:1, id:"RWD_141", lv1:"BO", lv2:"회원정보 보수", title:"휴대폰 번호 변경 등으로 인한 계정 분실 관련", reqby:"심성봉", worker:"", date:"2026-05-27", prio:3, status:"wait", est:null, start:null, end:null, act:null, judge:"notstarted", note:"" },
      { sr:1, id:"RWD_140", lv1:"운영", lv2:"아이디 중복 생성 건", title:"통합회원 테이블에 중복 데이터 중 1건 삭제", reqby:"더파르나스", worker:"진영우", date:"2026-05-27", prio:3, status:"done", est:1, start:"2026-05-27", end:"2026-05-27", act:1, judge:"normal", note:"통합회원 테이블 에서 중복 데이터 중 1건 삭제" },
      { sr:1, id:"RWD_139", lv1:"FO/BO", lv2:"기능 개발", title:"예약완료 시 고객에게 LMS 발송", req:"RWD_007", reqby:"심성봉", worker:"", date:"2026-05-27", prio:2, status:"wait", est:null, start:null, end:null, act:null, judge:"notstarted", note:"" },
      { sr:1, id:"RWD_138", lv1:"운영", lv2:"회원정보 수정", title:"연락처 변경 요청건", reqby:"더파르나스", worker:"진영우", date:"2026-05-27", prio:3, status:"done", est:1, start:"2026-05-27", end:"2026-05-27", act:1, judge:"normal", note:"회원 전화번호 db 업데이트" },
      { sr:1, id:"RWD_137", lv1:"API", lv2:"보안", title:"NICE 신규 모듈 전환", req:"RWD_006", reqby:"심성봉", worker:"", date:"2026-05-26", prio:1, status:"wait", est:null, start:null, end:null, act:null, judge:"notstarted", note:"" },
      { sr:1, id:"RWD_136", lv1:"FO", lv2:"개인정보처리방침", title:"개인정보처리방침 약관 수정", req:"RWD_005", reqby:"심성봉", worker:"진영우", date:"2026-05-26", prio:3, status:"done", est:1, start:"2026-05-27", end:"2026-05-27", act:1, judge:"normal", note:"개인정보처리방침 신규 생성 후, DB 업데이트 (데이터 수정 후…" },
      { sr:1, id:"RWD_135", lv1:"FO/BO", lv2:"설정변경", title:"기업회원 기본 태그 설정 변경", req:"RWD_004", reqby:"심성봉", worker:"", date:"2026-05-26", prio:3, status:"wait", est:null, start:null, end:null, act:null, judge:"notstarted", note:"" },
      { sr:1, id:"RWD_134", lv1:"운영", lv2:"포인트 수기 조정 오류", title:"포인트 수기 조정 파일첨부시 에러 발생.", reqby:"심성봉", worker:"진영우", date:"2026-05-26", prio:3, status:"prog", est:1, start:"2026-05-26", end:null, act:null, judge:"ongoing", note:"" },
      { sr:1, id:"RWD_130", lv1:"FO/BO", lv2:"오류", title:"포탈 접속 후 로그인 전에 발생하는 오류 현상", req:"RWD_003", reqby:"심성봉", worker:"최영우", date:"2026-05-26", prio:1, status:"done", est:1, start:"2026-05-26", end:"2026-05-29", act:1, judge:"over", note:"" },
      { sr:1, id:"RWD_126", lv1:"FO", lv2:"화면", title:"마이페이지 > 회원정보 수정 내 비밀번호 항목 제거 & 비밀번호 생성", reqby:"심성봉", worker:"진영우", date:"2026-05-21", prio:3, status:"done", est:3, start:"2026-05-21", end:"2026-05-25", act:3, judge:"normal", note:"[메일] [업무요청] 비밀번호 관련 내용 요청의 건" },
    ],
  },
  {
    id: "ic", name: "IC", color: "#6541F2",
    tasks: [
      { sr:2, id:"IC_058", lv1:"FO", lv2:"객실예약", title:"객실 예약 캘린더 노출 일자 오류 수정", req:"IC_021", reqby:"심성봉", worker:"진영우", date:"2026-05-22", prio:2, status:"prog", est:2, start:"2026-05-22", end:null, act:null, judge:"ongoing", note:"캘린더 컴포넌트 타임존 보정" },
      { sr:2, id:"IC_057", lv1:"API", lv2:"연동", title:"PMS 객실 재고 실시간 연동 안정화", req:"IC_020", reqby:"이광석", worker:"최영우", date:"2026-05-20", prio:1, status:"done", est:4, start:"2026-05-20", end:"2026-05-23", act:4, judge:"normal", note:"" },
      { sr:2, id:"IC_056", lv1:"BO", lv2:"정산", title:"멤버십 등급별 할인 정산 리포트 추가", reqby:"심성봉", worker:"", date:"2026-05-19", prio:3, status:"wait", est:null, start:null, end:null, act:null, judge:"notstarted", note:"" },
    ],
  },
  {
    id: "westin", name: "웨스틴", color: "#00BDDE",
    tasks: [
      { sr:3, id:"WST_044", lv1:"FO", lv2:"프로모션", title:"썸머 패키지 기획전 랜딩 페이지 제작", req:"WST_015", reqby:"윤혜현", worker:"진영우", date:"2026-05-18", prio:2, status:"done", est:3, start:"2026-05-18", end:"2026-05-20", act:2, judge:"early", note:"[검토 요청] 썸머 프로모션 랜딩" },
      { sr:3, id:"WST_043", lv1:"운영", lv2:"회원", title:"중복 가입 회원 통합 처리 요청", reqby:"더파르나스", worker:"진영우", date:"2026-05-17", prio:3, status:"done", est:1, start:"2026-05-17", end:"2026-05-17", act:1, judge:"normal", note:"" },
      { sr:3, id:"WST_042", lv1:"FO/BO", lv2:"기능 개발", title:"마이페이지 예약 취소 사유 입력 기능 추가", reqby:"심성봉", worker:"", date:"2026-05-16", prio:2, status:"wait", est:null, start:null, end:null, act:null, judge:"notstarted", note:"" },
    ],
  },
  {
    id: "jeju", name: "제주", color: "#00BF40",
    tasks: [
      { sr:4, id:"JEJ_037", lv1:"운영", lv2:"포인트", title:"제휴 포인트 적립 누락 건 일괄 보정", reqby:"심성봉", worker:"진영우", date:"2026-05-15", prio:2, status:"prog", est:2, start:"2026-05-15", end:null, act:null, judge:"ongoing", note:"제휴사 정산 데이터 대사 진행 중" },
      { sr:4, id:"JEJ_036", lv1:"FO", lv2:"화면", title:"객실 상세 이미지 갤러리 UI 개선", req:"JEJ_011", reqby:"이광석", worker:"최영우", date:"2026-05-14", prio:3, status:"done", est:2, start:"2026-05-14", end:"2026-05-16", act:2, judge:"normal", note:"" },
    ],
  },
  {
    id: "ninetree", name: "나인트리", color: "#FF5E00",
    tasks: [
      { sr:5, id:"NT_029", lv1:"운영", lv2:"결제", title:"카드 결제 승인 지연 현상 원인 파악", reqby:"심성봉", worker:"진영우", date:"2026-05-13", prio:1, status:"done", est:2, start:"2026-05-13", end:"2026-05-14", act:1, judge:"early", note:"PG사 응답 지연 — 타임아웃 상향 조치" },
      { sr:5, id:"NT_028", lv1:"BO", lv2:"리포트", title:"일별 객실 가동률 대시보드 지표 추가", reqby:"윤혜현", worker:"", date:"2026-05-12", prio:3, status:"wait", est:null, start:null, end:null, act:null, judge:"notstarted", note:"" },
    ],
  },
  {
    id: "system", name: "응용시스템", color: "#878A93",
    tasks: [
      { sr:6, id:"SYS_018", lv1:"API", lv2:"보안", title:"전체 채널 공통 로그인 토큰 만료 정책 통일", req:"SYS_007", reqby:"심성봉", worker:"최영우", date:"2026-05-10", prio:1, status:"prog", est:5, start:"2026-05-10", end:null, act:null, judge:"ongoing", note:"OneID 연동 표준화 작업" },
      { sr:6, id:"SYS_017", lv1:"운영", lv2:"배치", title:"야간 배치 작업 실패 알림 슬랙 연동", reqby:"월말 정기 작업", worker:"진영우", date:"2026-05-08", prio:2, status:"done", est:1, start:"2026-05-08", end:"2026-05-08", act:1, judge:"normal", note:"" },
    ],
  },
];

const SUMMARY = {
  project: "파르나스 운영(네오)",
  baseDate: "2026-05-30",
  startDate: "2026-01-01",
  total: 566, done: 510, prog: 12, wait: 44, over: 1, risk: 0, early: 19,
  effort: 2346, completion: 90.1, docKB: 437.7, docMaxMB: 1,
};
