/* WBS app — render table, group rail, modals, theme/font toggles */
(function () {
  const $ = (s, r = document) => r.querySelector(s);

  const ic = (name, size = 16) =>
    `<span class="ic" style="--m:url(assets/icons/${name}.svg);width:${size}px;height:${size}px"></span>`;

  const esc = (s) => (s || "").replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));

  const dash = '<span class="muted">—</span>';

  function avatar(name) {
    if (!name) return dash;
    const color = PEOPLE[name] || "#878A93";
    const initial = name.slice(0, 1);
    return `<span class="person"><span class="av" style="background:${color}">${esc(initial)}</span>${esc(name)}</span>`;
  }

  const STATUS = {
    done: { cls: "done", label: "완료" },
    prog: { cls: "prog", label: "진행" },
    wait: { cls: "wait", label: "대기" },
  };
  function statusBadge(s) {
    const t = STATUS[s] || STATUS.wait;
    return `<span class="badge ${t.cls}"><span class="bdot"></span>${t.label}</span>`;
  }

  const JUDGE = {
    normal:     { cls: "normal", label: "정상", icon: "circle-check" },
    notstarted: { cls: "notstarted", label: "미착수", icon: "clock" },
    ongoing:    { cls: "ongoing", label: "진행중", icon: "refresh" },
    over:       { cls: "over", label: "기간초과", icon: "triangle-exclamation" },
    early:      { cls: "early", label: "조기완료", icon: "sparkle" },
  };
  function judgeBadge(j) {
    const t = JUDGE[j];
    if (!t) return dash;
    return `<span class="jbadge ${t.cls}">${ic(t.icon, 12)}${t.label}</span>`;
  }

  function lvChip(lv) {
    const key = lv.toLowerCase().replace("/", "");
    const known = ["fo", "bo", "api", "fobo"];
    const cls = known.includes(key) ? key : "";
    return `<span class="lv-chip ${cls}">${esc(lv)}</span>`;
  }

  function prio(p) {
    const map = { 1: "p1", 2: "p2", 3: "p3" };
    const labels = { 1: "P1", 2: "P2", 3: "P3" };
    return `<span class="prio ${map[p]}"><span class="pdot"></span>${labels[p]}</span>`;
  }

  function effort(v) {
    if (v == null) return dash;
    return `<span class="effort-val">${v}<small>M/D</small></span>`;
  }

  function dateCell(d) {
    return d ? esc(d) : `<span class="muted">연도-월-일</span>`;
  }

  function reqCell(r, taskId) {
    if (!r) return dash;
    return `<a class="req-link" href="#" data-req="${esc(r)}" data-task="${taskId}">${esc(r)}${ic("external-link", 12)}</a>`;
  }

  function taskRow(t) {
    return `<tr class="task">
      <td class="ctr"><span class="cb"></span></td>
      <td><span class="tag-sr">SR</span></td>
      <td><span class="id-mono">${esc(t.id)}</span></td>
      <td>${lvChip(t.lv1)}</td>
      <td>${esc(t.lv2)}</td>
      <td><div class="task-title">${t.isNew ? '<span class="badge-new">NEW</span>' : ""}<span class="ttl-text" data-edit="${t.id}">${esc(t.title)}</span></div></td>
      <td>${reqCell(t.req, t.id)}</td>
      <td>${avatar(t.reqby)}</td>
      <td>${avatar(t.worker)}</td>
      <td>${dateCell(t.date)}</td>
      <td class="ctr">${prio(t.prio)}</td>
      <td class="ctr">${statusBadge(t.status)}</td>
      <td class="num">${effort(t.est)}</td>
      <td>${dateCell(t.start)}</td>
      <td>${dateCell(t.end)}</td>
      <td class="num">${effort(t.act)}</td>
      <td class="ctr">${judgeBadge(t.judge)}</td>
      <td><div class="note-cell">${t.note ? esc(t.note) : dash}</div></td>
    </tr>`;
  }

  function groupStats(g) {
    const total = g.tasks.length;
    const done = g.tasks.filter((t) => t.status === "done").length;
    const est = g.tasks.reduce((s, t) => s + (t.est || 0), 0);
    const pct = total ? Math.round((done / total) * 100) : 0;
    return { total, done, est, pct };
  }

  function groupRow(g) {
    const s = groupStats(g);
    return `<tr class="group" data-group="${g.id}">
      <td colspan="18">
        <div class="group-cell">
          ${ic("chevron-down", 18)}
          <span class="g-name"><span class="g-bar-color" style="background:${g.color}"></span>${esc(g.name)}</span>
          <span class="g-count">${s.total}건</span>
          <div class="g-progress">
            <span class="g-effort">예상 ${s.est} M/D · 완료 ${s.done}건</span>
            <div class="g-track"><i style="width:${s.pct}%;background:${g.color}"></i></div>
            <span class="g-pct" style="color:${g.color}">${s.pct}%</span>
          </div>
        </div>
      </td>
    </tr>`;
  }

  // ---- render table ----
  const tbody = $("#tbody");
  tbody.innerHTML = GROUPS.map((g) => groupRow(g) + g.tasks.map(taskRow).join("")).join("");

  // ---- render group rail (+ TOP button) ----
  $("#rail").innerHTML =
    GROUPS.map(
      (g) => `<button class="r-item" data-jump="${g.id}"><span class="r-dot" style="background:${g.color}"></span>${esc(g.name)}</button>`
    ).join("") +
    `<div class="r-divider"></div>` +
    `<button class="r-item r-top" id="railTop">${ic("arrow-up", 16)}TOP</button>`;

  $("#rail").addEventListener("click", (e) => {
    if (e.target.closest("#railTop")) {
      $(".table-wrap").scrollTo({ top: 0, behavior: "smooth" });
      return;
    }
    const b = e.target.closest("[data-jump]");
    if (!b) return;
    const row = $(`tr.group[data-group="${b.dataset.jump}"]`);
    if (row) {
      const wrap = $(".table-wrap");
      wrap.scrollTo({ top: row.offsetTop - 60, behavior: "smooth" });
    }
  });

  // ---- render group manager list ----
  $("#gmList").innerHTML = GROUPS.map((g) => {
    const s = groupStats(g);
    return `<div class="gm-row">
      <span class="drag">⠿</span>
      <span class="g-swatch" style="background:${g.color}"></span>
      <span class="gm-name">${esc(g.name)}</span>
      <span class="gm-cnt">${s.total}건 · ${s.est} M/D</span>
      <div class="gm-act">
        <button title="이름 수정">${ic("pencil", 16)}</button>
        <button title="삭제">${ic("trash", 16)}</button>
      </div>
    </div>`;
  }).join("");

  // ---- row selection ----
  let selCount = 0;
  function refreshDel() {
    const del = $("#delBtn");
    del.disabled = selCount === 0;
    del.innerHTML = `${ic("trash")}선택 삭제${selCount ? ` (${selCount})` : ""}`;
  }
  tbody.addEventListener("click", (e) => {
    const cb = e.target.closest(".cb");
    if (!cb) return;
    const tr = cb.closest("tr.task");
    if (!tr) return;
    cb.classList.toggle("on");
    cb.innerHTML = cb.classList.contains("on") ? ic("check", 12) : "";
    tr.classList.toggle("sel", cb.classList.contains("on"));
    selCount += cb.classList.contains("on") ? 1 : -1;
    refreshDel();
  });
  $("#selAll").addEventListener("click", function () {
    const on = !this.classList.contains("on");
    this.classList.toggle("on", on);
    this.innerHTML = on ? ic("check", 12) : "";
    selCount = 0;
    tbody.querySelectorAll("tr.task .cb").forEach((cb) => {
      cb.classList.toggle("on", on);
      cb.innerHTML = on ? ic("check", 12) : "";
      cb.closest("tr").classList.toggle("sel", on);
      if (on) selCount++;
    });
    refreshDel();
  });

  // ---- group collapse ----
  tbody.addEventListener("click", (e) => {
    const gc = e.target.closest("tr.group .group-cell");
    if (!gc) return;
    if (e.target.closest(".g-progress")) return;
    const grow = gc.closest("tr.group");
    const chev = gc.querySelector(".ic");
    let collapsed = grow.dataset.collapsed === "1";
    collapsed = !collapsed;
    grow.dataset.collapsed = collapsed ? "1" : "0";
    chev.style.setProperty("--m", `url(assets/icons/${collapsed ? "chevron-right" : "chevron-down"}.svg)`);
    let n = grow.nextElementSibling;
    while (n && !n.classList.contains("group")) {
      n.classList.toggle("hidden", collapsed);
      n = n.nextElementSibling;
    }
  });

  // ---- modals ----
  function openModal(id) { $(id).classList.add("open"); }
  function closeModals() { document.querySelectorAll(".scrim.open").forEach((s) => s.classList.remove("open")); }
  $("#groupBtn").addEventListener("click", () => openModal("#groupModal"));
  $("#importBtn").addEventListener("click", () => { closeDd(); openModal("#importModal"); });
  $("#exportBtn").addEventListener("click", () => { closeDd(); openModal("#exportModal"); });
  document.querySelectorAll(".modal-close").forEach((b) => b.addEventListener("click", closeModals));
  // strict modal: backdrop clicks and ESC do NOT close — only 닫기 buttons do.

  // export option select
  $("#exportOpts").addEventListener("click", (e) => {
    const opt = e.target.closest(".opt");
    if (!opt) return;
    $("#exportOpts").querySelectorAll(".opt").forEach((o) => o.classList.remove("selected"));
    opt.classList.add("selected");
  });

  // ---- excel dropdown ----
  const excelDd = $("#excelDd");
  function closeDd() { excelDd.classList.remove("open"); }
  $("#excelBtn").addEventListener("click", (e) => { e.stopPropagation(); excelDd.classList.toggle("open"); });
  document.addEventListener("click", closeDd);
  excelDd.querySelector(".dd-menu").addEventListener("click", (e) => e.stopPropagation());

  // ---- theme toggle ----
  const html = document.documentElement;
  $("#themeToggle").addEventListener("click", () => {
    const dark = html.getAttribute("data-theme") === "dark";
    html.setAttribute("data-theme", dark ? "light" : "dark");
    $("#themeIcon").style.setProperty("--m", `url(assets/icons/${dark ? "moon" : "sun"}.svg)`);
    $("#themeToggle").classList.toggle("active", !dark);
  });

  // ---- font (어르신) toggle ----
  $("#fontToggle").addEventListener("click", () => {
    const large = html.getAttribute("data-fontmode") === "large";
    html.setAttribute("data-fontmode", large ? "normal" : "large");
    $("#fontToggle").classList.toggle("active", !large);
  });

  // ---- dashboard collapse ----
  $("#dashHandle").addEventListener("click", () => {
    const dash = $("#dash");
    const collapsed = dash.classList.toggle("hidden");
    $("#dashChev").style.setProperty("--m", `url(assets/icons/${collapsed ? "chevron-down" : "chevron-up"}.svg)`);
    $("#dashHandleText").textContent = collapsed ? "프로젝트 요약 펼치기" : "프로젝트 요약 접기";
    $("#dashSummary").classList.toggle("hidden", !collapsed);
  });

  // ---- scroll-away chrome: hide header when the table scrolls down ----
  const tableWrap = $(".table-wrap");
  const appEl = $(".app");
  tableWrap.addEventListener("scroll", () => {
    appEl.classList.toggle("scrolled", tableWrap.scrollTop > 8);
  });

  // ---- edit (작업 정보 수정) modal ----
  const TASK_INDEX = {};
  GROUPS.forEach((g) => g.tasks.forEach((t) => (TASK_INDEX[t.id] = { task: t, group: g })));

  // group select options (placeholder + groups)
  $("#ef-group").innerHTML =
    `<option value="">— 유형을 선택하세요 —</option>` +
    GROUPS.map((g) => `<option value="${g.id}">${esc(g.name)}</option>`).join("");

  function setVal(id, v) { const el = $(id); if (el) el.value = v == null ? "" : v; }

  let currentEditTask = null;

  function openEdit(id) {
    const entry = TASK_INDEX[id];
    if (!entry) return;
    const t = entry.task;
    currentEditTask = t;
    // restore edit-mode chrome
    $("#editTitle").textContent = "작업 정보 수정";
    $("#editSave").innerHTML = `${ic("check")}저장하기`;
    $("#ef-date-hint").classList.add("hidden");
    $("#editSubtitle").textContent = `${t.id} · 등록 정보 수정`;
    $("#ef-id").textContent = t.id;
    $("#ef-group").value = entry.group.id;
    setVal("#ef-lv1", t.lv1);
    setVal("#ef-lv2", t.lv2);
    setVal("#ef-detail", t.title);
    setVal("#ef-req", t.req);
    setVal("#ef-url", "");
    setVal("#ef-reqby", t.reqby);
    setVal("#ef-worker", t.worker);
    setVal("#ef-est", t.est);
    setVal("#ef-date", t.date);
    setVal("#ef-start", t.start);
    setVal("#ef-end", t.end);
    setVal("#ef-act", t.act);
    setVal("#ef-note", t.note);

    const link = $("#ef-req-link");
    if (t.req) { link.style.display = ""; link.querySelector("b").textContent = t.req; }
    else { link.style.display = "none"; }

    $("#ef-meta").innerHTML = t.end || t.start
      ? `<b>${t.date} 16:39:42</b>에 <b>airwav7@gmail.com</b>가 수정하였습니다.`
      : `아직 등록 정보가 저장되지 않았습니다.`;

    $("#editModal").classList.add("open");
  }

  function openNew() {
    currentEditTask = null;
    $("#editTitle").textContent = "운영 현황 입력";
    $("#editSubtitle").textContent = `${SUMMARY.project} · WBS에 새 행을 등록합니다`;
    $("#editSave").innerHTML = `${ic("check")}등록하기`;
    ["#ef-lv2","#ef-detail","#ef-req","#ef-url","#ef-reqby","#ef-worker","#ef-est","#ef-start","#ef-end","#ef-act","#ef-note"].forEach((id) => setVal(id, ""));
    $("#ef-group").value = "";
    $("#ef-lv1").value = "";
    $("#ef-id").textContent = "신규";
    setVal("#ef-date", SUMMARY.baseDate);
    $("#ef-date-hint").classList.remove("hidden");
    $("#ef-req-link").style.display = "none";
    $("#ef-meta").innerHTML = "";
    $("#editModal").classList.add("open");
  }
  $("#saveBtn").addEventListener("click", openNew);
  $("#addRowBtn").addEventListener("click", openNew);

  tbody.addEventListener("click", (e) => {
    const reqLink = e.target.closest(".req-link[data-task]");
    if (reqLink) { e.preventDefault(); openRequest(reqLink.dataset.task); return; }
    const cell = e.target.closest(".ttl-text[data-edit]");
    if (cell) openEdit(cell.dataset.edit);
  });

  // ---- request (작업 요청서) modal ----
  function ymdShort(d) { return d ? d.slice(2).replace(/-/g, "/") : "—/—/—"; }

  function openRequest(taskId) {
    const entry = TASK_INDEX[taskId];
    if (!entry) return;
    const t = entry.task;
    $("#rq-title").textContent = t.req || t.id;
    $("#rq-subtitle").textContent = `RWD · 요청일 ${ymdShort(t.date)} 14:20:31 · 수정일 ${ymdShort(t.date)} 14:20:32`;
    $("#rq-group").textContent = entry.group.name;
    $("#rq-reqby").textContent = t.reqby || "—";
    setVal("#rq-lv1", t.lv1);
    setVal("#rq-lv2", t.lv2);
    setVal("#rq-path", t.lv2);
    setVal("#rq-name", t.title);
    $("#rq-wbsid").textContent = t.id;
    setVal("#rq-detail", t.note ? `* ${t.title}\n> ${t.note}` : `* ${t.title}\n> 이미지/자료는 제작 완료되면 전달 드릴 예정이고, 일정 확보차원에서 미리 업무요청 등록합니다.`);
    $("#rq-applied").value = t.status === "done" ? "반영" : (t.status === "prog" ? "보류" : "—");
    $("#rq-confirm").value = t.status === "done" ? "완료" : "미완료";
    $("#rq-meta").innerHTML = `<b>${t.date} 14:20:32</b>에 <b>ssb@parnas.co.kr</b>가 수정하였습니다.`;
    $("#rq-basic").classList.remove("open");
    $("#rq-basic-bar").querySelector(".ic").style.setProperty("--m", "url(assets/icons/chevron-right.svg)");
    $("#reqModal").classList.add("open");
  }

  // edit modal → open linked request
  $("#ef-req-link").addEventListener("click", (e) => {
    e.preventDefault();
    if (currentEditTask) openRequest(currentEditTask.id);
  });

  // 기본 정보 collapse
  $("#rq-basic-bar").addEventListener("click", () => {
    const c = $("#rq-basic");
    const open = c.classList.toggle("open");
    $("#rq-basic-bar").querySelector(".ic").style.setProperty("--m", `url(assets/icons/chevron-${open ? "down" : "right"}.svg)`);
  });

  // tabs (visual only)
  document.querySelectorAll(".tab").forEach((t) =>
    t.addEventListener("click", () => {
      document.querySelectorAll(".tab").forEach((x) => x.classList.remove("active"));
      t.classList.add("active");
    })
  );
})();
